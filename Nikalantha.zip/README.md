# EulerSeries
Proyecto de Multiprocesadores para Ago-Dec 20222. Implementacion de la serie de Euler en 4 herramientas diferentes junto con tecnicas de paralelismo.
